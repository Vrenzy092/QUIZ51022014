/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quiz51022014;

/**
 *
 * @author Lab20703
 */
public class QUIZ51022014 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new DataNilaiMahasiswa();
    }
    
}
